import { createContext, useContext, useState } from 'react';

export type Role = 'customer' | 'worker' | 'cooperative' | 'admin';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
  avatar?: string;
  city?: string;
  verified?: boolean;
  workerId?: number; // links to WorkerRecord.id for worker accounts
}

interface AuthCtx {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  switchDemo: (role: Role) => void;
  registerCustomer: (name: string, email: string, password: string, city: string) => Promise<User>;
  storeRegisteredWorker: (email: string, password: string, workerId: number, name: string, city: string) => User;
}

const DEMO_USERS: Record<Role, User> = {
  customer: { id: 1, name: 'Priya Sharma', email: 'priya@demo.coserve.in', role: 'customer', city: 'Chennai', avatar: 'PS' },
  worker: { id: 2, name: 'Ravi Kumar', email: 'ravi@demo.coserve.in', role: 'worker', city: 'Chennai', verified: true, avatar: 'RK', workerId: 1 },
  cooperative: { id: 3, name: 'Meenakshi Sundaram', email: 'meenakshi@demo.coserve.in', role: 'cooperative', city: 'Chennai', avatar: 'MS' },
  admin: { id: 4, name: 'Admin User', email: 'admin@coserve.in', role: 'admin', avatar: 'AU' },
};

const DEMO_PASSWORDS: Record<string, Role> = {
  'priya@demo.coserve.in': 'customer',
  'ravi@demo.coserve.in': 'worker',
  'meenakshi@demo.coserve.in': 'cooperative',
  'admin@coserve.in': 'admin',
};

const AUTH_STORAGE_KEY = 'cs-registered-users';

interface StoredAuthUser {
  email: string;
  passwordHash: string; // plain text for demo — note: production must hash
  user: User;
}

function loadRegistered(): StoredAuthUser[] {
  try {
    const s = localStorage.getItem(AUTH_STORAGE_KEY);
    return s ? JSON.parse(s) : [];
  } catch { return []; }
}

function saveRegistered(users: StoredAuthUser[]) {
  try { localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(users)); } catch {}
}

const Ctx = createContext<AuthCtx>({
  user: null,
  login: async () => false,
  logout: () => {},
  switchDemo: () => {},
  registerCustomer: async () => ({ id: 0, name: '', email: '', role: 'customer' }),
  storeRegisteredWorker: () => ({ id: 0, name: '', email: '', role: 'worker' }),
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 600));
    // Check demo accounts (any password works for demo)
    const role = DEMO_PASSWORDS[email.toLowerCase()];
    if (role) {
      setUser(DEMO_USERS[role]);
      return true;
    }
    // Check registered users (localStorage)
    const registered = loadRegistered();
    const found = registered.find(u => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === password);
    if (found) {
      setUser(found.user);
      return true;
    }
    return false;
  };

  const logout = () => setUser(null);

  const switchDemo = (role: Role) => setUser(DEMO_USERS[role]);

  const registerCustomer = async (name: string, email: string, password: string, city: string): Promise<User> => {
    await new Promise(r => setTimeout(r, 400));
    const registered = loadRegistered();
    const maxId = registered.reduce((m, u) => Math.max(m, u.user.id), 100);
    const newUser: User = {
      id: maxId + 1,
      name,
      email,
      role: 'customer',
      city,
      avatar: name.split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2),
    };
    registered.push({ email, passwordHash: password, user: newUser });
    saveRegistered(registered);
    setUser(newUser);
    return newUser;
  };

  const storeRegisteredWorker = (email: string, password: string, workerId: number, name: string, city: string): User => {
    const registered = loadRegistered();
    const maxId = registered.reduce((m, u) => Math.max(m, u.user.id), 100);
    const newUser: User = {
      id: maxId + 1,
      name,
      email,
      role: 'worker',
      city,
      workerId,
      avatar: name.split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2),
    };
    registered.push({ email, passwordHash: password, user: newUser });
    saveRegistered(registered);
    setUser(newUser);
    return newUser;
  };

  return (
    <Ctx.Provider value={{ user, login, logout, switchDemo, registerCustomer, storeRegisteredWorker }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
