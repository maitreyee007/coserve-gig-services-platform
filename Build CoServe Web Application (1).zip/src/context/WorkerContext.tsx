import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { WORKERS as SEED_WORKERS } from '../data/mockData';

export interface WorkerRecord {
  id: number;
  name: string;
  avatar: string;
  service: string;
  skills: string[];
  certifications: string[];
  experience: number;
  rating: number;
  reviews: number;
  completedJobs: number;
  matchScore: number;
  availability: string;
  availableNow: boolean;
  city: string;
  area: string;
  distance: number;
  cooperative: string;
  verificationStatus: 'verified' | 'pending' | 'rejected';
  accountStatus: 'active' | 'suspended';
  priceMin: number;
  priceMax: number;
  priceLabel: string;
  priceTier: 'affordable' | 'standard' | 'premium';
  servicePricing: { service: string; min: number; max: number }[];
  eta: string;
  bio: string;
  phone: string;
  email: string;
  aadhaarMasked: string;
  address: string;
  cancellationRate: number;
  createdAt: string;
}

interface WorkerCtx {
  workers: WorkerRecord[];
  addWorker: (data: NewWorkerPayload) => WorkerRecord;
  updateWorker: (id: number, updates: Partial<WorkerRecord>) => void;
  verifyWorker: (id: number) => void;
  rejectWorker: (id: number) => void;
  suspendWorker: (id: number) => void;
  activateWorker: (id: number) => void;
  getWorker: (id: number) => WorkerRecord | undefined;
}

export interface NewWorkerPayload {
  name: string;
  phone: string;
  email: string;
  aadhaarNumber: string; // will be masked on store
  address: string;
  city: string;
  area: string;
  service: string;
  skills: string[];
  experience: number;
  priceMin: number;
  bio: string;
  availability: string;
}

const STORAGE_KEY = 'cs-workers-v2';

function deriveAvatar(name: string): string {
  const parts = name.trim().split(' ');
  return parts.length >= 2
    ? (parts[0][0] + parts[1][0]).toUpperCase()
    : name.slice(0, 2).toUpperCase();
}

function maskAadhaar(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (digits.length < 4) return 'XXXX XXXX ' + digits;
  return 'XXXX XXXX ' + digits.slice(-4);
}

function deriveTier(priceMin: number): 'affordable' | 'standard' | 'premium' {
  if (priceMin < 400) return 'affordable';
  if (priceMin < 600) return 'standard';
  return 'premium';
}

function initWorkers(): WorkerRecord[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed: WorkerRecord[] = JSON.parse(stored);
      if (parsed.length > 0) return parsed;
    }
  } catch {}
  return (SEED_WORKERS as unknown as WorkerRecord[]).map(w => ({
    ...w,
    accountStatus: 'active' as const,
    phone: '',
    email: '',
    aadhaarMasked: '',
    address: '',
    createdAt: new Date().toISOString(),
  }));
}

const Ctx = createContext<WorkerCtx>({
  workers: [],
  addWorker: () => ({ id: 0 } as WorkerRecord),
  updateWorker: () => {},
  verifyWorker: () => {},
  rejectWorker: () => {},
  suspendWorker: () => {},
  activateWorker: () => {},
  getWorker: () => undefined,
});

export function WorkerProvider({ children }: { children: ReactNode }) {
  const [workers, setWorkers] = useState<WorkerRecord[]>(initWorkers);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(workers)); } catch {}
  }, [workers]);

  const addWorker = (data: NewWorkerPayload): WorkerRecord => {
    const maxId = workers.reduce((m, w) => Math.max(m, w.id), 0);
    const priceMax = data.priceMin + Math.round(data.priceMin * 0.3);
    const newWorker: WorkerRecord = {
      id: maxId + 1,
      name: data.name,
      avatar: deriveAvatar(data.name),
      service: data.service,
      skills: data.skills,
      certifications: [],
      experience: data.experience,
      rating: 0,
      reviews: 0,
      completedJobs: 0,
      matchScore: 75,
      availability: data.availability,
      availableNow: data.availability === 'Available Now',
      city: data.city,
      area: data.area,
      distance: 2.5,
      cooperative: 'Independent Worker',
      verificationStatus: 'pending',
      accountStatus: 'active',
      priceMin: data.priceMin,
      priceMax,
      priceLabel: `₹${data.priceMin}–₹${priceMax}`,
      priceTier: deriveTier(data.priceMin),
      servicePricing: [{ service: data.service, min: data.priceMin, max: priceMax }],
      eta: '15–25 min',
      bio: data.bio,
      phone: data.phone,
      email: data.email,
      aadhaarMasked: maskAadhaar(data.aadhaarNumber),
      address: data.address,
      cancellationRate: 0,
      createdAt: new Date().toISOString(),
    };
    setWorkers(prev => [...prev, newWorker]);
    return newWorker;
  };

  const updateWorker = (id: number, updates: Partial<WorkerRecord>) => {
    setWorkers(prev => prev.map(w => {
      if (w.id !== id) return w;
      const merged = { ...w, ...updates };
      // Keep derived fields in sync if priceMin changed
      if (updates.priceMin !== undefined) {
        const pMax = updates.priceMax ?? merged.priceMin + Math.round(merged.priceMin * 0.3);
        merged.priceMax = pMax;
        merged.priceLabel = `₹${merged.priceMin}–₹${pMax}`;
        merged.priceTier = deriveTier(merged.priceMin);
      }
      if (updates.name !== undefined) {
        merged.avatar = deriveAvatar(updates.name);
      }
      return merged;
    }));
  };

  const verifyWorker = (id: number) =>
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, verificationStatus: 'verified' } : w));

  const rejectWorker = (id: number) =>
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, verificationStatus: 'rejected' } : w));

  const suspendWorker = (id: number) =>
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, accountStatus: 'suspended' } : w));

  const activateWorker = (id: number) =>
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, accountStatus: 'active' } : w));

  const getWorker = (id: number) => workers.find(w => w.id === id);

  return (
    <Ctx.Provider value={{ workers, addWorker, updateWorker, verifyWorker, rejectWorker, suspendWorker, activateWorker, getWorker }}>
      {children}
    </Ctx.Provider>
  );
}

export const useWorkers = () => useContext(Ctx);
