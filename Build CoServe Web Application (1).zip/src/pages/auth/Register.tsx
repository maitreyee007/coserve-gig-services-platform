import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, ChevronRight } from 'lucide-react';
import Button from '../../components/ui/Button';
import { useToast } from '../../components/ui/Toast';

type Role = 'customer' | 'worker' | 'cooperative';

export default function Register() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [role, setRole] = useState<Role>('customer');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', city: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setLoading(false);
    toast('Account created! Please log in with the demo accounts.', 'success');
    navigate('/login');
  };

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12" style={{ background: 'var(--bg)' }}>
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white" style={{ background: 'var(--cs-teal)' }}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="3" fill="white" opacity="0.9" />
                <line x1="10" y1="2" x2="10" y2="7" stroke="white" strokeWidth="2" strokeLinecap="round" />
                <line x1="10" y1="13" x2="10" y2="18" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
            <span className="font-bold text-xl" style={{ color: 'var(--cs-teal)' }}>CoServe</span>
          </Link>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>Create your account</h1>
          <p className="mt-1 text-sm" style={{ color: 'var(--text-secondary)' }}>
            Already have an account? <Link to="/login" className="font-medium" style={{ color: 'var(--cs-teal)' }}>Sign in</Link>
          </p>
        </div>

        <div
          className="rounded-2xl border p-6"
          style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
        >
          {/* Role selector */}
          <div className="mb-6">
            <label className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>I want to join as</label>
            <div className="grid grid-cols-3 gap-2">
              {([
                { r: 'customer', label: 'Customer', icon: '🏠' },
                { r: 'worker', label: 'Worker', icon: '🔧' },
                { r: 'cooperative', label: 'Cooperative', icon: '🤝' },
              ] as const).map(({ r, label, icon }) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRole(r)}
                  className={`flex flex-col items-center py-3 px-2 rounded-xl border text-xs font-medium transition-all ${
                    role === r ? 'border-[var(--cs-teal)]' : ''
                  }`}
                  style={role === r
                    ? { background: '#e8f4f7', borderColor: 'var(--cs-teal)', color: 'var(--cs-teal)' }
                    : { background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-secondary)' }
                  }
                >
                  <span className="text-xl mb-1">{icon}</span>
                  {label}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>Full Name *</label>
              <input
                type="text" required value={form.name} onChange={e => set('name', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                placeholder="Your full name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>Email *</label>
              <input
                type="email" required value={form.email} onChange={e => set('email', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>Phone *</label>
              <input
                type="tel" required value={form.phone} onChange={e => set('phone', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                placeholder="+91 98765 43210"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>City *</label>
              <input
                type="text" required value={form.city} onChange={e => set('city', e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                placeholder="Chennai"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--text-primary)' }}>Password *</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'} required value={form.password}
                  onChange={e => set('password', e.target.value)} minLength={8}
                  className="w-full px-4 py-2.5 pr-11 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                  style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                  placeholder="Minimum 8 characters"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }}>
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {role === 'worker' && (
              <div className="p-3 rounded-xl text-xs" style={{ background: '#e8f5f0', color: '#1a6b52' }}>
                After registration, your profile will be <strong>Pending Verification</strong>. An admin or cooperative manager will verify your identity and skills.
              </div>
            )}

            <Button type="submit" className="w-full" size="lg" loading={loading} icon={<ChevronRight size={16} />}>
              {loading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
