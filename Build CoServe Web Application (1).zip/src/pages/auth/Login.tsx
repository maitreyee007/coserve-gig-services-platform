import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ShieldCheck, User, Wrench, Eye, EyeOff, ArrowLeft, ArrowRight } from 'lucide-react';
import { useAuth, Role } from '../../context/AuthContext';
import Button from '../../components/ui/Button';
import { useToast } from '../../components/ui/Toast';

type RoleChoice = 'customer' | 'worker' | 'admin';

const ROLE_CARDS: { id: RoleChoice; icon: React.ReactNode; label: string; desc: string; color: string; bg: string }[] = [
  {
    id: 'customer',
    icon: <User size={28} />,
    label: 'Customer',
    desc: 'Find verified workers for household services',
    color: '#0F4C5C',
    bg: '#e8f4f7',
  },
  {
    id: 'worker',
    icon: <Wrench size={28} />,
    label: 'Worker',
    desc: 'Offer your skills and grow with the cooperative',
    color: '#2E8B70',
    bg: '#e8f9f4',
  },
  {
    id: 'admin',
    icon: <ShieldCheck size={28} />,
    label: 'Admin',
    desc: 'Manage workers, customers, and platform operations',
    color: '#6B5B95',
    bg: '#f3f0ff',
  },
];

const DEMO_HINTS: Record<RoleChoice, { email: string; label: string }> = {
  customer: { email: 'priya@demo.coserve.in', label: 'Demo Customer' },
  worker:   { email: 'ravi@demo.coserve.in',  label: 'Demo Worker' },
  admin:    { email: 'admin@coserve.in',       label: 'Demo Admin' },
};

const DASHBOARD_ROUTES: Record<RoleChoice, string> = {
  customer: '/customer/dashboard',
  worker:   '/worker/dashboard',
  admin:    '/admin/dashboard',
};

export default function Login() {
  const navigate = useNavigate();
  const { login, switchDemo } = useAuth();
  const { toast } = useToast();

  const [step, setStep] = useState<'role' | 'login'>('role');
  const [roleChoice, setRoleChoice] = useState<RoleChoice>('customer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const hint = DEMO_HINTS[roleChoice];
  const card = ROLE_CARDS.find(r => r.id === roleChoice)!;

  const handleRoleSelect = (r: RoleChoice) => {
    setRoleChoice(r);
    setEmail('');
    setPassword('');
    setStep('login');
  };

  const handleDemoLogin = () => {
    switchDemo(roleChoice as Role);
    toast(`Signed in as ${hint.label}`, 'success');
    navigate(DASHBOARD_ROUTES[roleChoice]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const ok = await login(email, password);
    setLoading(false);
    if (ok) {
      toast('Welcome back!', 'success');
      navigate(DASHBOARD_ROUTES[roleChoice]);
    } else {
      toast('Invalid email or password', 'error');
    }
  };

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--bg)' }}>
      {/* Left decorative panel */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12" style={{ background: '#0F4C5C' }}>
        <div>
          <div className="flex items-center gap-2 mb-12">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm" style={{ background: '#F4B942', color: '#0F4C5C' }}>C</div>
            <span className="font-bold text-xl text-white">CoServe</span>
          </div>
          <h1 className="text-4xl font-extrabold text-white leading-tight mb-4">
            Trusted Services.<br />
            <span style={{ color: '#F4B942' }}>Empowered Workers.</span><br />
            Stronger Communities.
          </h1>
          <p className="text-base leading-relaxed" style={{ color: 'rgba(255,255,255,0.7)' }}>
            CoServe connects households with verified, cooperative-backed skilled workers — electricians, plumbers, cleaners, and more.
          </p>
        </div>
        <div className="space-y-3">
          {[
            'Every worker identity & skill verified',
            'Cooperative model — fair earnings for workers',
            'Transparent pricing, no hidden charges',
            'Two-stage OTP for safety & trust',
          ].map(text => (
            <div key={text} className="flex items-center gap-3">
              <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0" style={{ background: '#2E8B70', color: 'white' }}>✓</span>
              <span className="text-sm" style={{ color: 'rgba(255,255,255,0.8)' }}>{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-16 py-12">
        <div className="max-w-md w-full mx-auto">

          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm" style={{ background: '#0F4C5C', color: '#F4B942' }}>C</div>
            <span className="font-bold text-xl" style={{ color: 'var(--text-primary)' }}>CoServe</span>
          </div>

          {/* STEP 1: Role selection */}
          {step === 'role' && (
            <>
              <h2 className="text-2xl font-bold mb-1" style={{ color: 'var(--text-primary)' }}>Welcome to CoServe</h2>
              <p className="text-sm mb-7" style={{ color: '#667477' }}>Choose how you want to continue</p>

              <div className="space-y-3 mb-8">
                {ROLE_CARDS.map(rc => (
                  <button
                    key={rc.id}
                    onClick={() => handleRoleSelect(rc.id)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border text-left transition-all hover:shadow-md hover:-translate-y-0.5"
                    style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
                  >
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: rc.bg, color: rc.color }}>
                      {rc.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-sm" style={{ color: 'var(--text-primary)' }}>{rc.label}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#667477' }}>{rc.desc}</p>
                    </div>
                    <ArrowRight size={16} style={{ color: '#667477' }} />
                  </button>
                ))}
              </div>

              <p className="text-xs text-center" style={{ color: '#667477' }}>
                New customer?{' '}
                <Link to="/register" className="font-semibold" style={{ color: '#0F4C5C' }}>Create account</Link>
                {' · '}
                <Link to="/worker/register" className="font-semibold" style={{ color: '#2E8B70' }}>Register as Worker</Link>
              </p>
            </>
          )}

          {/* STEP 2: Login form */}
          {step === 'login' && (
            <>
              <button
                onClick={() => setStep('role')}
                className="flex items-center gap-1.5 text-sm mb-6 hover:opacity-70 transition-opacity"
                style={{ color: '#667477' }}
              >
                <ArrowLeft size={14} /> Back
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: card.bg, color: card.color }}>
                  {card.icon}
                </div>
                <div>
                  <h2 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>Sign in as {card.label}</h2>
                  <p className="text-xs" style={{ color: '#667477' }}>{card.desc}</p>
                </div>
              </div>

              {/* Quick demo */}
              <div className="mb-5 p-4 rounded-2xl border" style={{ background: 'var(--bg)', borderColor: 'var(--border)' }}>
                <p className="text-xs font-semibold mb-2" style={{ color: '#667477' }}>Quick demo access (no password needed)</p>
                <button
                  onClick={handleDemoLogin}
                  className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-opacity hover:opacity-90"
                  style={{ background: card.color }}
                >
                  Continue as {hint.label}
                </button>
              </div>

              <div className="flex items-center gap-3 mb-5">
                <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
                <span className="text-xs" style={{ color: '#667477' }}>or sign in with email</span>
                <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-primary)' }}>Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder={hint.email}
                    required
                    className="w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2"
                    style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1.5" style={{ color: 'var(--text-primary)' }}>Password</label>
                  <div className="relative">
                    <input
                      type={showPw ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="Enter password"
                      required
                      className="w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 pr-10"
                      style={{ background: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                    />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: '#667477' }}>
                      {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>
                <Button type="submit" className="w-full" size="lg" loading={loading} style={{ background: card.color }}>
                  Sign In
                </Button>
              </form>

              {roleChoice === 'worker' && (
                <div className="mt-5 p-4 rounded-2xl border text-center" style={{ background: 'var(--bg)', borderColor: 'var(--border)' }}>
                  <p className="text-sm mb-2" style={{ color: '#667477' }}>New to CoServe as a worker?</p>
                  <Link to="/worker/register">
                    <button className="px-5 py-2 rounded-xl text-sm font-bold border-2 transition-all hover:shadow-md" style={{ borderColor: '#2E8B70', color: '#2E8B70' }}>
                      Register as a Worker →
                    </button>
                  </Link>
                </div>
              )}

              {roleChoice === 'customer' && (
                <p className="text-xs text-center mt-4" style={{ color: '#667477' }}>
                  No account?{' '}
                  <Link to="/register" className="font-semibold" style={{ color: '#0F4C5C' }}>Create one free</Link>
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
