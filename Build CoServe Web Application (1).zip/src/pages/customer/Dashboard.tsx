import { Link } from 'react-router-dom';
import { Search, Clock, CheckCircle, Star, Bell, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import DashboardLayout from '../../components/layout/DashboardLayout';
import StatCard from '../../components/ui/StatCard';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import { BOOKINGS, WORKERS, NOTIFICATIONS } from '../../data/mockData';

function BookingStatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { label: string; variant: 'verified' | 'pending' | 'rejected' | 'neutral' | 'amber' | 'teal' }> = {
    COMPLETED: { label: 'Completed', variant: 'verified' },
    ACCEPTED: { label: 'Accepted', variant: 'teal' },
    PENDING: { label: 'Pending', variant: 'amber' },
    CANCELLED: { label: 'Cancelled', variant: 'neutral' },
    REJECTED: { label: 'Rejected', variant: 'rejected' },
  };
  const c = cfg[status] || { label: status, variant: 'neutral' };
  return <Badge variant={c.variant}>{c.label}</Badge>;
}

export default function CustomerDashboard() {
  const { user } = useAuth();

  return (
    <DashboardLayout>
      {/* Welcome */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
            Good morning, {user?.name.split(' ')[0]} 👋
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--text-secondary)' }}>What service do you need today?</p>
        </div>
        <Link to="/notifications">
          <Button variant="secondary" size="sm" icon={<Bell size={14} />}>
            Notifications <span className="ml-1 px-1.5 py-0.5 rounded-full text-xs text-white" style={{ background: '#D9534F' }}>2</span>
          </Button>
        </Link>
      </div>

      {/* Search bar */}
      <div className="relative mb-6">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
        <Link to="/workers">
          <div
            className="w-full pl-11 pr-4 py-3 rounded-2xl border text-sm cursor-pointer"
            style={{ background: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text-muted)' }}
          >
            Search for a service or worker...
          </div>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <StatCard label="Active Bookings" value="1" icon={<Clock size={18} style={{ color: 'var(--cs-teal)' }} />} trend="1 upcoming" trendUp />
        <StatCard label="Completed" value="12" icon={<CheckCircle size={18} style={{ color: '#2E8B70' }} />} />
        <StatCard label="Avg Rating Given" value="4.8" icon={<Star size={18} style={{ color: '#F4B942' }} />} />
        <StatCard label="Favourite Workers" value="3" icon={<ShieldCheck size={18} style={{ color: 'var(--cs-teal)' }} />} />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent bookings */}
        <div className="lg:col-span-2 rounded-2xl border" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <h2 className="font-semibold" style={{ color: 'var(--text-primary)' }}>My Bookings</h2>
            <Link to="/customer/bookings" className="text-xs font-medium flex items-center gap-1" style={{ color: 'var(--cs-teal)' }}>
              View all <ArrowRight size={12} />
            </Link>
          </div>
          <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
            {BOOKINGS.map(b => (
              <div key={b.id} className="px-5 py-4 flex items-start gap-4">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                  style={{ background: 'var(--cs-teal)' }}>
                  {b.worker.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm truncate" style={{ color: 'var(--text-primary)' }}>{b.service}</p>
                    <BookingStatusBadge status={b.status} />
                  </div>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{b.worker} · {b.date}</p>
                  {b.isUrgent && <Badge variant="amber" size="sm" className="mt-1">Urgent</Badge>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended workers */}
        <div className="rounded-2xl border" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
            <h2 className="font-semibold" style={{ color: 'var(--text-primary)' }}>Recommended</h2>
            <Link to="/workers" className="text-xs font-medium flex items-center gap-1" style={{ color: 'var(--cs-teal)' }}>
              See more <ArrowRight size={12} />
            </Link>
          </div>
          <div className="p-4 space-y-3">
            {WORKERS.slice(0, 3).map(w => (
              <Link key={w.id} to={`/workers/${w.id}`}>
                <div className="flex items-center gap-3 p-3 rounded-xl transition-colors hover:bg-[var(--bg)]">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0 relative"
                    style={{ background: 'var(--cs-teal)' }}>
                    {w.avatar}
                    {w.verificationStatus === 'verified' && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#2E8B70' }}>
                        <ShieldCheck size={8} color="white" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>{w.name}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{w.service}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs flex items-center gap-0.5" style={{ color: '#F4B942' }}>
                        <Star size={10} fill="#F4B942" /> {w.rating}
                      </span>
                      <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                        <MapPin size={10} className="inline" /> {w.distance}km
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold shrink-0" style={{ color: 'var(--cs-teal)' }}>{w.matchScore}%</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Recent notifications */}
      <div className="mt-6 rounded-2xl border" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
        <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
          <h2 className="font-semibold" style={{ color: 'var(--text-primary)' }}>Recent Activity</h2>
        </div>
        <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
          {NOTIFICATIONS.map(n => (
            <div key={n.id} className={`flex items-start gap-3 px-5 py-3.5 ${!n.isRead ? 'bg-[#f0f9fa]' : ''}`}>
              <div className="w-2 h-2 rounded-full mt-1.5 shrink-0" style={{ background: n.isRead ? 'var(--border)' : 'var(--cs-teal)' }} />
              <div>
                <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{n.title}</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{n.message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
