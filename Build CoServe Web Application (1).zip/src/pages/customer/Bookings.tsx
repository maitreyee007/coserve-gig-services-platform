import { useState } from 'react';
import { Star } from 'lucide-react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import Badge from '../../components/ui/Badge';
import Button from '../../components/ui/Button';
import { BOOKINGS } from '../../data/mockData';
import { useToast } from '../../components/ui/Toast';

const STATUS_BADGE: Record<string, 'verified' | 'amber' | 'teal' | 'rejected' | 'neutral'> = {
  COMPLETED: 'verified',
  ACCEPTED: 'teal',
  PENDING: 'amber',
  CANCELLED: 'neutral',
  REJECTED: 'rejected',
};

export default function CustomerBookings() {
  const { toast } = useToast();
  const [filter, setFilter] = useState('ALL');

  const filtered = filter === 'ALL' ? BOOKINGS : BOOKINGS.filter(b => b.status === filter);

  return (
    <DashboardLayout title="My Bookings" subtitle="Track and manage your service requests">
      <div className="flex flex-wrap gap-2 mb-6">
        {['ALL', 'PENDING', 'ACCEPTED', 'COMPLETED', 'CANCELLED'].map(s => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors`}
            style={filter === s
              ? { background: 'var(--cs-teal)', color: 'white' }
              : { background: 'var(--surface)', color: 'var(--text-secondary)', border: '1px solid var(--border)' }
            }
          >
            {s === 'ALL' ? 'All' : s.charAt(0) + s.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 rounded-2xl border" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
          <p className="font-bold text-lg mb-2" style={{ color: 'var(--text-primary)' }}>No Bookings</p>
          <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>You don't have any bookings yet.</p>
          <Button size="sm">Find a Service</Button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(b => (
            <div key={b.id} className="rounded-2xl border p-5" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold" style={{ color: 'var(--text-primary)' }}>{b.service}</h3>
                    <Badge variant={STATUS_BADGE[b.status]}>{b.status.charAt(0) + b.status.slice(1).toLowerCase()}</Badge>
                    {b.isUrgent && <Badge variant="amber" size="sm">Urgent</Badge>}
                  </div>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {b.worker} · {b.date} at {b.time}
                  </p>
                  <p className="text-xs mt-1 truncate" style={{ color: 'var(--text-muted)' }}>{b.address}</p>
                  {b.description && (
                    <p className="text-xs mt-1 italic" style={{ color: 'var(--text-muted)' }}>{b.description}</p>
                  )}
                </div>
                <div className="text-right shrink-0">
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Booking ID</p>
                  <p className="font-mono text-sm font-bold" style={{ color: 'var(--cs-teal)' }}>{b.id}</p>
                  <p className="text-sm font-bold mt-1" style={{ color: 'var(--text-primary)' }}>
                    ₹{b.finalPrice || b.estimatedPrice}
                  </p>
                </div>
              </div>

              {b.status === 'COMPLETED' && b.finalPrice && (
                <div className="mt-4 p-4 rounded-xl border" style={{ background: '#f0f9fa', borderColor: '#b3d5df' }}>
                  <p className="text-xs font-semibold mb-2" style={{ color: 'var(--cs-teal)' }}>Digital Receipt</p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <p style={{ color: 'var(--text-muted)' }}>Customer Paid</p>
                      <p className="font-bold" style={{ color: 'var(--text-primary)' }}>₹{b.customerPaid}</p>
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)' }}>Worker Earnings</p>
                      <p className="font-bold" style={{ color: '#2E8B70' }}>₹{b.workerEarnings}</p>
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)' }}>Cooperative Fund</p>
                      <p className="font-bold" style={{ color: '#F4B942' }}>₹{b.cooperativeContribution}</p>
                    </div>
                    <div>
                      <p style={{ color: 'var(--text-muted)' }}>Platform Fee</p>
                      <p className="font-bold" style={{ color: 'var(--text-secondary)' }}>₹{b.platformFee}</p>
                    </div>
                  </div>
                  {b.rating && (
                    <div className="flex items-center gap-1 mt-3">
                      <span className="text-xs" style={{ color: 'var(--text-muted)' }}>Your rating:</span>
                      {Array(b.rating).fill(0).map((_, i) => (
                        <Star key={i} size={12} fill="#F4B942" color="#F4B942" />
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-2 mt-4">
                {b.status === 'PENDING' && (
                  <Button size="sm" variant="danger" onClick={() => toast('Booking cancelled', 'info')}>
                    Cancel Booking
                  </Button>
                )}
                {b.status === 'COMPLETED' && !b.rating && (
                  <Button size="sm" onClick={() => toast('Thank you for your rating!', 'success')}>
                    Leave a Review
                  </Button>
                )}
                {b.status === 'COMPLETED' && (
                  <Button size="sm" variant="secondary" onClick={() => toast('Dispute raised. We will review shortly.', 'info')}>
                    Raise Dispute
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
