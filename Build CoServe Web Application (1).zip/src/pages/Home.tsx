import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ShieldCheck, Star, Users, TrendingUp, Zap, ArrowRight,
  CheckCircle, MapPin, Clock, Award, BarChart2, Heart,
  ChevronRight, Briefcase, Search, Building2
} from 'lucide-react';
import { SERVICES, WORKERS, COOPERATIVES, ADMIN_STATS } from '../data/mockData';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';

const TESTIMONIALS = [
  {
    name: 'Divya Menon',
    role: 'Customer, Adyar',
    text: 'Ravi fixed our ceiling fan in under an hour. Verified, professional and fair price. I always check the Trust Score now before booking.',
    rating: 5,
    avatar: 'DM',
  },
  {
    name: 'Karthik Balaji',
    role: 'Customer, Anna Nagar',
    text: "The Smart Match showed me three plumbers with full transparency — their ratings, reliability, cooperative affiliation. It felt trustworthy.",
    rating: 5,
    avatar: 'KB',
  },
  {
    name: 'Sunita Rao',
    role: 'Customer, Velachery',
    text: 'I loved seeing the earnings breakdown. ₹400 to the worker, ₹50 to the cooperative, ₹50 platform fee. Total transparency.',
    rating: 5,
    avatar: 'SR',
  },
];

function HeroWorkerCard() {
  return (
    <div className="relative">
      {/* Main card */}
      <div
        className="rounded-3xl p-6 shadow-2xl border max-w-xs mx-auto"
        style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
      >
        <div className="flex items-start gap-4">
          <div className="relative">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-xl font-bold"
              style={{ background: 'var(--cs-teal)' }}
            >
              RK
            </div>
            <div
              className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center"
              style={{ background: '#2E8B70' }}
            >
              <ShieldCheck size={13} color="white" />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-base" style={{ color: 'var(--text-primary)' }}>Ravi Kumar</h3>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Electrician</p>
            <div className="flex items-center gap-1 mt-1">
              <Star size={13} fill="#F4B942" color="#F4B942" />
              <span className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>4.9</span>
              <span className="text-xs" style={{ color: 'var(--text-muted)' }}>(87 reviews)</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4">
          <div className="flex flex-col items-center py-2.5 rounded-xl" style={{ background: 'var(--bg)' }}>
            <span className="text-2xl font-bold" style={{ color: '#2E8B70' }}>124+</span>
            <span className="text-xs mt-0.5 font-medium" style={{ color: 'var(--text-secondary)' }}>👥 Customers</span>
          </div>
          <div className="flex flex-col items-center py-2.5 rounded-xl" style={{ background: '#e8f4f7' }}>
            <span className="text-2xl font-bold" style={{ color: 'var(--cs-teal)' }}>94%</span>
            <span className="text-xs font-medium" style={{ color: 'var(--cs-teal)' }}>Match Score</span>
          </div>
        </div>
        <div className="mt-2 text-center">
          <span className="text-xs font-bold" style={{ color: '#2E8B70' }}>✓ Verified Worker · From ₹350/visit</span>
        </div>

        <div className="mt-3 px-3 py-2 rounded-xl flex items-center gap-2" style={{ background: 'var(--bg)' }}>
          <Users size={13} style={{ color: 'var(--cs-emerald)' }} />
          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>Anna Nagar Electrical Workers Coop</span>
        </div>
      </div>

      {/* Floating chips */}
      <div
        className="absolute -top-3 -left-4 px-3 py-1.5 rounded-xl shadow-lg border text-xs font-medium flex items-center gap-1.5"
        style={{ background: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
      >
        <MapPin size={11} style={{ color: 'var(--cs-teal)' }} /> 2.4 km away
      </div>
      <div
        className="absolute -bottom-3 -right-4 px-3 py-1.5 rounded-xl shadow-lg border text-xs font-medium flex items-center gap-1.5"
        style={{ background: '#2E8B70', color: 'white' }}
      >
        <Clock size={11} /> Available Today
      </div>
      <div
        className="absolute top-16 -right-8 px-3 py-1.5 rounded-xl shadow-lg border text-xs font-medium"
        style={{ background: 'var(--cs-amber)', color: '#172326' }}
      >
        124 Jobs Completed
      </div>
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/workers?q=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div className="page-enter">
      {/* Hero */}
      <section className="relative overflow-hidden" style={{ background: 'var(--bg)' }}>
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, #0F4C5C 0%, transparent 50%), radial-gradient(circle at 80% 20%, #2E8B70 0%, transparent 40%)'
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-6"
                style={{ background: '#e8f4f7', color: 'var(--cs-teal)' }}
              >
                <Users size={12} /> SIH 2026 — Cooperative Gig Services Platform
              </div>
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-extrabold leading-tight text-balance">
                <span style={{ color: 'var(--text-primary)' }}>Trusted Services.</span>
                <br />
                <span style={{ color: 'var(--cs-teal)' }}>Empowered Workers.</span>
                <br />
                <span style={{ color: 'var(--cs-emerald)' }}>Stronger Communities.</span>
              </h1>
              <p className="text-lg mt-5 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Connect with verified skilled workers from cooperative societies for reliable household and community services.
              </p>

              {/* Search bar */}
              <form onSubmit={handleSearch} className="mt-7 flex gap-2">
                <input
                  type="text"
                  placeholder="Search: Electrician, Plumber, Cleaner..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-[var(--cs-teal)] transition"
                  style={{ background: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--text-primary)' }}
                />
                <Button type="submit" size="lg">Find</Button>
              </form>

              {/* CTAs */}
              <div className="flex flex-wrap gap-3 mt-5">
                <Link to="/services">
                  <Button size="lg" icon={<Search size={16} />}>Find a Service</Button>
                </Link>
                <Link to="/emergency">
                  <button
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold text-white transition-opacity hover:opacity-90"
                    style={{ background: '#D9534F' }}
                  >
                    🚨 Need Help Now?
                  </button>
                </Link>
                <Link to="/register">
                  <Button variant="secondary" size="lg">Join as a Worker</Button>
                </Link>
              </div>
              <p className="text-xs mt-3" style={{ color: 'var(--text-muted)' }}>
                Affordable rates from ₹250 · All workers cooperative-verified
              </p>

              {/* Social proof */}
              <div className="flex items-center gap-6 mt-8">
                <div className="text-center">
                  <p className="text-2xl font-bold" style={{ color: 'var(--cs-teal)' }}>380+</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Verified Workers</p>
                </div>
                <div className="h-8 w-px" style={{ background: 'var(--border)' }} />
                <div className="text-center">
                  <p className="text-2xl font-bold" style={{ color: 'var(--cs-teal)' }}>24</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Cooperatives</p>
                </div>
                <div className="h-8 w-px" style={{ background: 'var(--border)' }} />
                <div className="text-center">
                  <p className="text-2xl font-bold" style={{ color: 'var(--cs-teal)' }}>4.8★</p>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Avg Rating</p>
                </div>
              </div>
            </div>

            {/* Hero visual */}
            <div className="hidden lg:flex items-center justify-center py-8">
              <HeroWorkerCard />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>How CoServe Works</h2>
            <p className="mt-2" style={{ color: 'var(--text-secondary)' }}>From request to service — transparent, verified, cooperative.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { step: '01', icon: Search, title: 'Search a Service', desc: 'Tell us what you need — electrical, plumbing, cleaning and more.' },
              { step: '02', icon: Zap, title: 'Smart Matching', desc: 'Our algorithm finds the best verified worker based on skill, distance, availability and reliability.' },
              { step: '03', icon: ShieldCheck, title: 'Verified Worker', desc: 'Every worker is identity verified, skill tested and cooperative approved.' },
              { step: '04', icon: CheckCircle, title: 'Service Done Right', desc: 'Track in real time. Rate. Get a digital receipt with transparent earnings breakdown.' },
            ].map(({ step, icon: Icon, title, desc }) => (
              <div key={step} className="relative">
                <div
                  className="rounded-2xl p-6 h-full border transition-shadow hover:shadow-md"
                  style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
                >
                  <div className="flex items-start gap-3 mb-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: '#e8f4f7' }}
                    >
                      <Icon size={18} style={{ color: 'var(--cs-teal)' }} />
                    </div>
                    <span className="text-3xl font-black leading-none" style={{ color: 'var(--step-number-color)' }}>{step}</span>
                  </div>
                  <h3 className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{title}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Smart Matching */}
      <section className="py-16 border-t" style={{ background: 'var(--cs-teal)', borderColor: 'transparent' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-4" style={{ background: 'rgba(244,185,66,0.2)', color: '#F4B942' }}>
                <Zap size={12} /> Rule-Based Smart Matching Algorithm
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">Finding Your Perfect Worker</h2>
              <p className="text-base leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.75)' }}>
                CoServe's Smart Matching Engine scores workers across six dimensions — not just stars and reviews. Only verified workers appear in results.
              </p>
              <div className="space-y-3">
                {[
                  { label: 'Skill Match', pct: 35, color: '#F4B942' },
                  { label: 'Availability', pct: 25, color: '#2E8B70' },
                  { label: 'Distance', pct: 15, color: '#5BA8D9' },
                  { label: 'Rating', pct: 10, color: '#A78BFA' },
                  { label: 'Experience', pct: 10, color: '#34D399' },
                  { label: 'Reliability', pct: 5, color: '#F87171' },
                ].map(({ label, pct, color }) => (
                  <div key={label} className="flex items-center gap-3">
                    <span className="text-xs w-28 shrink-0" style={{ color: 'rgba(255,255,255,0.75)' }}>{label}</span>
                    <div className="flex-1 h-2 rounded-full" style={{ background: 'rgba(255,255,255,0.15)' }}>
                      <div className="h-2 rounded-full transition-all" style={{ width: `${pct * 2}%`, background: color }} />
                    </div>
                    <span className="text-xs font-bold text-white w-8">{pct}%</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              {/* Sample match card */}
              <div className="rounded-3xl overflow-hidden shadow-2xl" style={{ background: 'var(--surface)' }}>
                <div className="px-5 py-3 flex items-center justify-between" style={{ background: '#2E8B70' }}>
                  <span className="text-xs text-white font-semibold uppercase tracking-wider">Best Match</span>
                  <span className="text-white font-bold text-lg">94% Match</span>
                </div>
                <div className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold text-lg shrink-0" style={{ background: 'var(--cs-teal)' }}>
                      RK
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold" style={{ color: 'var(--text-primary)' }}>Ravi Kumar</h3>
                        <Badge variant="emerald" icon={<ShieldCheck size={10} />} size="sm">Verified</Badge>
                      </div>
                      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Electrician · 5 yrs experience</p>
                      <div className="flex items-center gap-1 mt-1">
                        <Star size={13} fill="#F4B942" color="#F4B942" />
                        <span className="text-sm font-semibold">4.9</span>
                        <span className="text-xs text-[var(--text-muted)] ml-1">· 2.4 km · Available tomorrow</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-base font-bold" style={{ color: '#0F4C5C' }}>94%</div>
                      <div className="text-xs" style={{ color: '#667477' }}>Match</div>
                    </div>
                  </div>
                  <div className="mt-4 p-3 rounded-xl" style={{ background: 'var(--bg)' }}>
                    <p className="text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>Why recommended:</p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {['Skill match', 'Available today', 'Nearby (2.4 km)', 'Identity verified', 'Highly reliable', 'Cooperative member'].map(r => (
                        <span key={r} className="text-xs flex items-center gap-1" style={{ color: 'var(--cs-emerald)' }}>
                          <CheckCircle size={11} /> {r}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="px-3 py-2 rounded-xl mt-3 flex items-center gap-2" style={{ background: '#e8f4f7' }}>
                    <Users size={13} style={{ color: 'var(--cs-emerald)' }} />
                    <span className="text-xs" style={{ color: 'var(--cs-teal)' }}>Anna Nagar Electrical Workers Cooperative</span>
                  </div>
                  <Button className="w-full mt-4">Book Ravi Kumar</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Services */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>Popular Services</h2>
              <p className="mt-1" style={{ color: 'var(--text-secondary)' }}>Book a verified professional for any home need</p>
            </div>
            <Link to="/services" className="flex items-center gap-1 text-sm font-medium" style={{ color: 'var(--cs-teal)' }}>
              View all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {SERVICES.map(s => (
              <Link
                key={s.id}
                to={`/workers?service=${encodeURIComponent(s.name)}`}
                className="group rounded-2xl border p-5 transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 text-center"
                style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
              >
                <div className="text-3xl mb-3">{s.icon}</div>
                <h3 className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>{s.name}</h3>
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>From ₹{s.basePrice}</p>
                <div className="mt-3 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1" style={{ color: 'var(--cs-teal)' }}>
                  Find workers <ChevronRight size={12} />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Cooperative Model */}
      <section className="py-16 border-t" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>The Cooperative Advantage</h2>
            <p className="mt-2 max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
              CoServe is not just another booking platform. Workers are organized into registered cooperatives — giving them collective strength, welfare support, and fair earnings.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Users,
                title: 'For Customers',
                color: 'var(--cs-teal)',
                bg: '#e8f4f7',
                points: ['Verified, trusted workers', 'Smart matching algorithm', 'Transparent pricing', 'Digital service receipts', 'Dispute resolution'],
              },
              {
                icon: Award,
                title: 'For Workers',
                color: '#2E8B70',
                bg: '#e8f5f0',
                points: ['Fair and transparent earnings', 'Skill Passport & Trust Score', 'Cooperative welfare support', 'More job opportunities', 'Workload management'],
              },
              {
                icon: Building2,
                title: 'For Cooperatives',
                color: '#8B5E3C',
                bg: '#f5ede8',
                points: ['Digital management dashboard', 'Demand analytics', 'Worker performance tracking', 'Collective cooperative fund', 'Community growth tools'],
              },
            ].map(({ icon: Icon, title, color, bg, points }) => (
              <div
                key={title}
                className="rounded-2xl border p-6 transition-shadow hover:shadow-md"
                style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
              >
                <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4" style={{ background: bg }}>
                  <Icon size={20} style={{ color }} />
                </div>
                <h3 className="font-bold text-lg mb-3" style={{ color: 'var(--text-primary)' }}>{title}</h3>
                <ul className="space-y-2">
                  {points.map(p => (
                    <li key={p} className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                      <CheckCircle size={14} style={{ color }} className="shrink-0" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fair Earnings */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Transparent Earnings Breakdown</h2>
              <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>
                Every rupee is accounted for. Workers see exactly what they earn, cooperatives see their fund contribution, customers see fair pricing.
              </p>
              <div
                className="rounded-2xl border overflow-hidden"
                style={{ borderColor: 'var(--border)' }}
              >
                <div className="px-5 py-3" style={{ background: 'var(--cs-teal)', color: 'white' }}>
                  <p className="text-sm font-semibold">Service: Electrical Repair</p>
                  <p className="text-xs opacity-75">Customer Paid: ₹500</p>
                </div>
                {[
                  { label: 'Worker Earnings', amount: 400, pct: 80, color: '#2E8B70' },
                  { label: 'Cooperative Fund', amount: 50, pct: 10, color: '#F4B942' },
                  { label: 'Platform Sustainability', amount: 50, pct: 10, color: '#667477' },
                ].map(({ label, amount, pct, color }) => (
                  <div key={label} className="px-5 py-4 border-b flex items-center justify-between gap-4" style={{ borderColor: 'var(--border)', background: 'var(--surface)' }}>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{label}</span>
                        <span className="text-sm font-bold" style={{ color }}>₹{amount}</span>
                      </div>
                      <div className="h-1.5 rounded-full" style={{ background: 'var(--bg)' }}>
                        <div className="h-1.5 rounded-full" style={{ width: `${pct}%`, background: color }} />
                      </div>
                    </div>
                    <span className="text-xs font-semibold shrink-0" style={{ color: 'var(--text-muted)' }}>{pct}%</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              {[
                { icon: ShieldCheck, title: 'Trust Score', desc: 'Separate from star ratings — calculated from verification, reliability, certifications and job history.' },
                { icon: Zap, title: 'Smart Matching', desc: 'Rule-based algorithm with explainable recommendations. Not AI or ML — transparent scoring you can understand.' },
                { icon: Heart, title: 'Worker Welfare', desc: 'Workload monitoring, welfare indicators and cooperative support prevent worker burnout.' },
                { icon: BarChart2, title: 'Demand Analytics', desc: 'Cooperatives see which services are most in demand, where and when — enabling better workforce planning.' },
              ].map(({ icon: Icon, title, desc }) => (
                <div
                  key={title}
                  className="flex gap-4 p-4 rounded-2xl border transition-shadow hover:shadow-sm"
                  style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: '#e8f4f7' }}>
                    <Icon size={18} style={{ color: 'var(--cs-teal)' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-1" style={{ color: 'var(--text-primary)' }}>{title}</h4>
                    <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Cooperatives */}
      <section className="py-16 border-t" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>Partner Cooperatives</h2>
              <p className="mt-1" style={{ color: 'var(--text-secondary)' }}>Worker-owned cooperative societies powering CoServe</p>
            </div>
            <Link to="/cooperatives" className="flex items-center gap-1 text-sm font-medium" style={{ color: 'var(--cs-teal)' }}>
              View all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            {COOPERATIVES.slice(0, 2).map(c => (
              <div
                key={c.id}
                className="rounded-2xl border p-5 transition-shadow hover:shadow-md"
                style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-sm shrink-0" style={{ background: 'var(--cs-teal)' }}>
                    {c.shortName[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>{c.name}</h3>
                      <Badge variant="emerald" size="sm">{c.badge}</Badge>
                    </div>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{c.speciality} · {c.city}</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="text-center">
                    <p className="text-lg font-bold" style={{ color: 'var(--cs-teal)' }}>{c.members}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Members</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold" style={{ color: 'var(--cs-teal)' }}>{c.completedJobs}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Jobs Done</p>
                  </div>
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Star size={13} fill="#F4B942" color="#F4B942" />
                      <p className="text-lg font-bold" style={{ color: 'var(--cs-teal)' }}>{c.rating}</p>
                    </div>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Rating</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold" style={{ color: 'var(--text-primary)' }}>What Customers Say</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {TESTIMONIALS.map(t => (
              <div
                key={t.name}
                className="rounded-2xl border p-6 transition-shadow hover:shadow-md"
                style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}
              >
                <div className="flex gap-0.5 mb-4">
                  {Array(t.rating).fill(0).map((_, i) => (
                    <Star key={i} size={14} fill="#F4B942" color="#F4B942" />
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--text-secondary)' }}>"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: 'var(--cs-teal)' }}>
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{t.name}</p>
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Stats */}
      <section className="py-12 border-t" style={{ background: 'var(--cs-teal)', borderColor: 'transparent' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <p className="text-center text-xs mb-6 opacity-60 text-white">Demo statistics — illustrative data</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
            {[
              { value: '1,240', label: 'Services Completed' },
              { value: '380', label: 'Verified Workers' },
              { value: '24', label: 'Cooperatives' },
              { value: '18', label: 'Communities Served' },
              { value: '₹4.8L', label: 'Worker Earnings' },
            ].map(({ value, label }) => (
              <div key={label}>
                <p className="text-3xl font-extrabold text-white">{value}</p>
                <p className="text-sm mt-1 opacity-70 text-white">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 border-t" style={{ borderColor: 'var(--border)' }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
            Ready to experience cooperative services?
          </h2>
          <p className="mb-8" style={{ color: 'var(--text-secondary)' }}>
            Join CoServe — whether you need a service, want to offer your skills, or manage a cooperative workforce.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link to="/register"><Button size="lg">Get Started Free</Button></Link>
            <Link to="/workers"><Button size="lg" variant="secondary">Browse Workers</Button></Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-10" style={{ background: 'var(--surface)', borderColor: 'var(--border)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white" style={{ background: 'var(--cs-teal)' }}>
                <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
                  <circle cx="10" cy="10" r="3" fill="white" opacity="0.9" />
                  <line x1="10" y1="2" x2="10" y2="7" stroke="white" strokeWidth="2" strokeLinecap="round" />
                  <line x1="10" y1="13" x2="10" y2="18" stroke="white" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="font-bold" style={{ color: 'var(--cs-teal)' }}>CoServe</span>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#e8f4f7', color: 'var(--cs-teal)' }}>SIH 2026</span>
            </div>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              Cooperative Services. Stronger Communities. · Problem Statement SIH26089
            </p>
            <div className="flex gap-4 text-xs" style={{ color: 'var(--text-secondary)' }}>
              <Link to="/about" className="hover:underline">About</Link>
              <Link to="/how-it-works" className="hover:underline">How It Works</Link>
              <Link to="/cooperatives" className="hover:underline">Cooperatives</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

